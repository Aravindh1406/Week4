const express=require("express")
const {getStudents,getStudent,createNewStudent,modifyStudent,deleteStudent}=require("../controllers/controllersSql")
const router=express.Router()
router.route("/").get(getStudents)
router.route("/:id").get(getStudent)
router.route("/").post(createNewStudent)
router.route("/:id").put(modifyStudent)
router.route("/:id").delete(deleteStudent)
module.exports=router