const mongoose=require("mongoose")
const addressSchema=new mongoose.Schema({
    street:{
        type:String,
        required:true
    },
    city:{
        type:String,
        required:true
    },
    state:{
        type:String,
        required:true
    },
    zipCode:{
        type:Number,
        required:true
    }
},{
    timestamps:false
}); 

const studentSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true,
        unique:true
    },
    branch:{
        type:String,
        required:true
    },
    cgpa:{
        type:Number,
        required:true
    },
    address:{
        type:addressSchema,
        required:true
    }
}, {timestamps:false});
const Students=mongoose.model("Students",studentSchema)
module.exports=Students