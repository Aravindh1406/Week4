const {Sequelize,DataTypes}=require("sequelize")
const sequelize=require("../config/connectdbsql")
const Student=sequelize.define("students",{
    id:{
        type:DataTypes.INTEGER,
        allowNull:false,
        primaryKey:true,
        autoIncrement:true
    },
    name:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    branch:{
        type:DataTypes.STRING,
        allowNull:false
    },
    cgpa:{
        type:DataTypes.FLOAT,
        allowNull:false
    }
},
{
    timestamps:false
})
const Address=sequelize.define("addresses",{
    street:{
        type:DataTypes.STRING,
        allowNull:false
    },
    city:{
        type:DataTypes.STRING,
        allowNull:false
    },
    state:{
        type:DataTypes.STRING,
        allowNull:false
    },
    zipCode:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
    studentId: {
        type:DataTypes.INTEGER,
        allowNull:false,
        references:{
            model:Student,
            key:"id"
        },
        onDelete:"CASCADE"
    }
}, {
    timestamps: false,
    primaryKey: false
});
Student.hasOne(Address)
Address.belongsTo(Student)
sequelize.sync({alter:true})
.then(()=>{
    console.log("Tables Created")
})
.catch((err)=>{
    console.log("Error in Creating Table")
})
module.exports={Student,Address}