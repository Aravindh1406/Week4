
const mongoose=require("mongoose")
require("dotenv").config()
const studentDetails=process.env.CONNECTION_STRING
const connectDB=async()=>{
    try{
        const connection=await mongoose.connect(studentDetails)
        console.log("Connection Successful")
        console.log("Connection Host:",connection.connection.host)
        console.log("DataBase Name:",connection.connection.name)
    }
    catch(err){
        console.log(err)
        process.exit(1)
    }

}
module.exports=connectDB
