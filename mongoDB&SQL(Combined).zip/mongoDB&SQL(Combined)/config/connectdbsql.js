const Sequelize=require("sequelize")
const sequelize=new Sequelize("studentDetails","root","-Aravindh12",{
    dialect:"mysql",
    host:"localhost",
    logging:false
})
const checkConnection=async()=>{
    try{
        await sequelize.authenticate()
    }
    catch(err){
    }
}
checkConnection()
.then(()=>{
    console.log("Connection Successful")
})
.catch((err)=>{
    console.log("Not Connected to DataBase")
    console.log(err)
})
module.exports=sequelize
