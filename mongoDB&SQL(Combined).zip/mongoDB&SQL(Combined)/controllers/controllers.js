const StudentsMdb=require("../models/schema")
const {Student,Address}=require("../models/scehmasql")
const getStudents=(async(req,res)=>{
    const studentinMongo=await StudentsMdb.find()
    const studentinSql=await Student.findAll({include:Address})
    /*const sqlRes=studentinSql.map(student=>({
        id:student.id,
        name:student.name,
        branch:student.branch,
        cgpa:student.cgpa,
        address:student.address?{
            street:student.address.street,
            city:student.address.city,
            state:student.address.state,
            zipCode:student.address.zipCode
        }:null
    }));*/
    res.status(200).json({message:"Students Data retrieved",studentinSql,studentinMongo})
})
const mongoose = require("mongoose");
const getStudentById=async(req,res)=>{
    try{
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            const studentinMongo=await StudentsMdb.findById(req.params.id)
            if(studentinMongo){
            return res.status(200).json({message:"student Found",studentinMongo})
            }
        }
        const studentinSql=await Student.findByPk(req.params.id,{include:Address})
        if(studentinSql){
            return res.status(200).json({message:"student Found",studentinSql})
        }
        return res.status(404).json({ message: "No student found" });
    } 
    catch(err){
        console.log(err.message)
        res.status(500).json({message:"Server error",error: err.message})
    }
}
const createStudent=(async(req,res)=>{
    try{
            const studentMdb=await StudentsMdb.create(req.body)
            const {name,branch,cgpa,address}=req.body
            console.log(req.body)
            const student=await Student.create({name,branch,cgpa})
            const Addresss=await Address.create({
                street:address.street,
                city:address.city,
                state:address.state,
                zipCode:address.zipCode,
                studentId:student.id
            })
            /*const sqlRes={
                id:student.id,
                name:student.name,
                branch:student.branch,
                cgpa:student.cgpa,
                address:{
                    street:Addresss.street,
                    city:Addresss.city,
                    state:Addresss.state,
                    zipCode:Addresss.zipCode
                }
            }*/
            res.status(201).json({message:"New Student Created",SQL:student,Addresss,mongoDB:studentMdb})
        }
    catch(err){
        console.log(err.message)
        res.status(500).json({message:"Server error",error: err.message})
    }
})
const createStudents=(async(req,res)=>{
    try{
        console.log(req.body)
        const {name,age,branch,cgpa,Address}=req.body
        const newStudents=await Students.insertMany(req.body)
        res.status(201).json({message:"Students Successfully Added",student:newStudents})
    }
    catch(err){
        console.log(err.message)
        res.status(500).json({message:"Server error",error:err.message})
    }
})
const updateStudent=(async(req,res)=>{
    try{
        const{name,age,cgpa,address}=req.body
        if(mongoose.Types.ObjectId.isValid(req.params.id)){
            const student=await StudentsMdb.findById(req.params.id)
            if(student){
                await StudentsMdb.updateOne({ _id: req.params.id }, { $set: req.body });
                const updatedStudentInMongo=await StudentsMdb.findById(req.params.id)
                return res.status(200).json({message:"Updated Successfully",updatedStudentInMongo})
            }
        }
        const findStudent=await Student.findByPk(req.params.id)
        console.log(findStudent)
        if(!findStudent){
            return res.status(404).json("student Not Found")
        }
            await findStudent.update({name,age,cgpa})
            const studentAddress=await Address.findOne({where:{studentId:findStudent.id}})
            console.log(studentAddress)
            if(studentAddress){
                if(address){
                   await studentAddress.update({
                    street:address.street,
                    city:address.city,
                    state:address.state,
                    zipCode:address.zipCode})
                }
            }
            const studentBasicData=await Student.findByPk(req.params.id)
            return res.status(200).json({message:"student Updated",SQL:studentBasicData,studentAddress})
    } 
    catch(err){
        console.log(err.message)
        res.status(500).json({message:"Server error",error: err.message})
    }
})
const deleteStudent=(async(req,res)=>{
    try{
        const student=await StudentsMdb.findById(req.params.id)
        if(!student){
            return res.status(404).json({message:"No student Found"})
        }
        await StudentsMdb.deleteOne({_id:req.params.id})
        res.status(200).json({message:"Student Details Deleted"})
    }
    catch(err){
        console.log(err.message)
        res.status(500).json({message:"Server error",error: err.message})
    }
})
const deleteStudents=(async(req,res)=>{
    try{
        await StudentsMdb.deleteMany({})
        res.status(200).json({message:"Students Details Deleted"})
    }
    catch(err){
        console.log(err.message)
        res.status(500).json({message:"Server error",error: err.message})
    }
})


module.exports={getStudents,getStudentById,createStudent,createStudents,updateStudent,deleteStudent,deleteStudents}
