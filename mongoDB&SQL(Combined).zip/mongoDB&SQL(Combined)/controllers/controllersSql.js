const Student=require("../models/scehmasql")
const getStudents=(async(req,res)=>{
    res.status(200).json({message:"Student Details are:"})
})
const getStudent=(async(req,res)=>{
    res.status(200).json({message:"Student with Given id is:"})
})
const createNewStudent=(async(req,res)=>{
    try{
        const {name,branch,cgpa,address}=req.body
        console.log(req.body)
        const student=await Student.create(name,branch,cgpa)
        const newStudent=await Student.create({
            street:address.street,
            city:address.city,
            state:address.state,
            zipcode:address.zipcode
            //studentId:student.id
        })
        res.status(201).json({message:"New Student Created"})
    }
    catch(err){
        res.status(500).json("Error")
        console.log("Error")
    }
})
const modifyStudent=(async(req,res)=>{
    res.status(200).json({message:"Student Updated Successfully"})
})
const deleteStudent=(async(req,res)=>{
    res.status(200).json({message:"Student Deleted Successfully"})
})
module.exports={getStudents,getStudent,createNewStudent,modifyStudent,deleteStudent}