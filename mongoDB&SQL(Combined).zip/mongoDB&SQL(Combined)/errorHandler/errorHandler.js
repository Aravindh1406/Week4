const errorHandler=(error,req,res,next)=>{
    const statusCode=res.statusCode?res.statusCode:500
    res.status(statusCode);
    switch(statusCode){
        case 404:res.json({
            title:"Not Found",
            message:`${error.message}`,
            statusCode:`${statusCode}`,
            stackTrace:`${error.stack}`
        })
        break;
        case 500:res.json({
            title:"Internal Server Error",
            message:`${error.message}`,
            statusCode:`${statusCode}`,
            stackTrace:`${error.stack}`
        })
        break;
        default:break;
    }
    
}
module.exports=errorHandler