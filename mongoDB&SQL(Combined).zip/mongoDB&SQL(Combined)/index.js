const express=require("express")
require("dotenv").config();
const connectDB=require("./config/connectdb")
connectDB()
const {Student,Address}=require("./models/scehmasql")
const routes=require("./routes/routes");
const errorHandler = require("./errorHandler/errorHandler");
const port=process.env.PORT||3000
const app=express()
app.use(express.json())
app.use("/students",routes)
app.use(errorHandler)
app.listen(port,()=>{
    console.log("Server running on Port:",port)
})