import connectDB from "./config/db.js"
const startServer=async()=>{
    try{
        await connectDB();
    }
    catch(err){
        console.log(err)
        process.exit(1);
    }
}
startServer()