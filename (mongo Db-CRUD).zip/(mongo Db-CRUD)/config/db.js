import mongoose, { modelNames } from "mongoose"
import dotenv from "dotenv" 
dotenv.config();
const employeeDetails=process.env.CONNECTION_STRING
console.log(employeeDetails)
const connectDB=async()=>{
    try{
        const connect=await mongoose.connect(employeeDetails)
        console.log("DataBase Connected")
        console.log("Host Name:",connect.connection.host)
        console.log("DataBase Name:",connect.connection.name)
    }
    catch(err){
        console.log(err)
    }
}
export default connectDB


