import mongoose from "mongoose"
const employeeSchema=mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    /*Gender:{
        type:String,
        required:true
    },
    age:{
        type:Number,
        required:true
    },
    PhoneNumber:{
        type:String,
        required:true
    },
    dob:{
        type:Date,
        required:true
    },
    dept:{
        type:String,
        required:true
    },
    rating:{
        type:float,
        required:true
    }*/
},
{
    timestamps:false
})
const Employee=mongoose.model("Employee",employeeSchema)
export default Employee
