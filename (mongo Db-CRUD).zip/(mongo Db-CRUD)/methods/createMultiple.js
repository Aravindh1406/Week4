import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
const employees=[{name:"bob",email:"bob123@gmail.com"},
    {name:"candy",email:"candy123@gmail.com"}
]
const createEmployees=async()=>{
    try{
        await connectDB()
       const emp=await Employee.insertMany(employees)
       console.log("Employees Created...")
       emp.forEach(employee=> {
        console.log("Employee Name:",employee.name)
        console.log("Employee Mail Id:",employee.email)
       });
    }
    catch(err){
        console.log(err)
    }
}
createEmployees()
