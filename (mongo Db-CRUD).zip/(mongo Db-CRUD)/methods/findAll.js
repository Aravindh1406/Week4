import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
const findEmployees=async()=>{
    try{
        await connectDB()
       const employees=await Employee.find()
       if(employees.length>0)
       {
        console.log("Employees Found...")
        employees.forEach((employee)=>{
            console.log("Employee Name:",employee.name)
            console.log("Employee Mail Id:",employee.email)
        })
       }
       else{
        console.log("No Employee Found")
       }
    }
    catch(err){
        console.log(err)
    }
}
findEmployees()
