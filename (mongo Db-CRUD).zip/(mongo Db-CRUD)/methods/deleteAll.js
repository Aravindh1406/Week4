import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
const deleteEmployees=async()=>{
    try{
        await connectDB()
       const employees=await Employee.deleteMany()
       console.log("All employees details are deleted")
    }
    catch(err){
        console.log(err)
    }
}
deleteEmployees()
