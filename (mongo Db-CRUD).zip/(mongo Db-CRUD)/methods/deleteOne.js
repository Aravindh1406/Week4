import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
export const createEmployee=async()=>{
    try{
        await connectDB()
        const employee=await Employee.findOne({name:"Alice"})
        if(employee)
        {
            await Employee.deleteOne({name:employee.name})
            console.log("Employee Deleted...")
        }
        else{
            console.log("No employee Found...")
        }
    }
    catch(err){
        console.log(err)
    }
}
createEmployee()
