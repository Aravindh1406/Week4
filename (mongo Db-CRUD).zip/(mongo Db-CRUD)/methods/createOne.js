import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
const createEmployee=async()=>{
    try{
        await connectDB()
       const employee=await Employee.create({name:"Dolly",email:"dolly123@gmail.com"})
       console.log("Employee Created...")
       console.log("Employee Name:",employee.name)
       console.log("Employee Mail Id:",employee.email)
    }
    catch(err){
        console.log(err)
    }
}
createEmployee()
