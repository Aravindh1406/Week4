import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
export const findEmployee=async()=>{
    try{
        await connectDB()
       const employee=await Employee.findOne({name:"Mandy"})
       if(employee)
       {
        console.log("Employee Found...")
       console.log("Employee Name:",employee.name)
       console.log("Employee Mail Id:",employee.email)
       }
       else{
        console.log("No Employee Found")
       }
    }
    catch(err){
        console.log(err)
    }
}
findEmployee()
