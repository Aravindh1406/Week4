import { connect } from "http2"
import Employee from "../models/employeeModel.js"
import connectDB from "../config/db.js"
const updateEmployee=async()=>{
    try{
        await connectDB()
       const employee=await Employee.updateOne({name:"Bob"},{$set:{name:"Bob",email:"bob123@gmail.com"}})
       console.log("Employee updated...")
       /*console.log("Employee Name:",employee.name)
       console.log("Employee Mail Id:",employee.email)*/
       console.log("After Updation:",await Employee.find({name:"Bob"}))
    }
    catch(err){
        console.log(err)
    }
}
updateEmployee()
